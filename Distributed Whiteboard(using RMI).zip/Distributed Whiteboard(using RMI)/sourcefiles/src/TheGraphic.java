// Runzhe Hua 1310690


import java.awt.*;
import java.io.Serializable;

class TheGraphic implements Serializable {
    public String shape;
    public int colour;
    public int[] location;

    public TheGraphic(String s,Color c,int[] positions){
        shape = s;
        colour = c.getRGB();
        location = positions;
    }
}
