// Runzhe Hua 1310690


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;
import java.util.*;


public class Client {
    protected JTextField textField1 = new JTextField();
    protected JButton button1 = new JButton("confirm");
    protected JTextField showtext = new JTextField();
    protected JPanel Panel = new JPanel();
    protected JFrame paint = new JFrame("White Board");
    protected JPanel jp = new JPanel(new GridLayout(15, 1, 10, 10));
    protected JPanel canvas;
    protected static JFrame f;
    protected JTextArea userlist = new JTextArea();
    protected JTextArea inputArea = new JTextArea();
    protected String username;
    protected Color currentColour = Color.BLACK;
    protected ArrayList<String> chat;
    protected JTextArea chatArea = new JTextArea();
    protected String currentShape = "None";
    protected JTextField typeChat = new JTextField();
    protected int x1;
    protected int y1;
    protected int x2;
    protected int y2;
    protected Graphics2D grap;
    protected boolean isLeagalUsername = false;
    protected ArrayList<TheGraphic> graphicList = new ArrayList<>();
    protected UpdateList up;
    protected static String ip = "localhost";
    protected static int port = 3614;


    public Client() throws Exception {
        Panel.add(showtext);
        textField1.setPreferredSize(new Dimension(150, 30));
        Panel.add(textField1);
        Panel.add(button1);
        showtext.setEditable(false);
        showtext.setText("Please enter your user name");
        inputArea.setBackground(Panel.getBackground());
        showtext.setPreferredSize(new Dimension(290, 64));
        showtext.setFont(new Font("Lightnin Std", Font.PLAIN, 18));
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String message = "";
                try (Socket socket = new Socket(ip, port);) {
                    username = textField1.getText();
                    // Output and Input Stream
                    DataInputStream input = new DataInputStream(socket.getInputStream());
                    DataOutputStream output = new DataOutputStream(socket.getOutputStream());
                    String sendData = username;
                    output.writeUTF(sendData);
                    System.out.println("Data sent to Server--> " + sendData);
                    output.flush();
                    boolean flag = true;
                    while (flag) {
                        if (input.available() > 0) {
                            message = input.readUTF();
                            System.out.println(message);
                            flag = false;
                        }
                    }
                    if (message.equalsIgnoreCase("Name accepted")) {
                        isLeagalUsername = true;
                    }
                    showtext.setText("The username is already in used");
                    showtext.setFont(new Font("Consolas", Font.PLAIN, 12));
                    showtext.setForeground(Color.RED);


                } catch (IOException ee) {
                    System.out.println(ee.toString());
                }
                System.out.println(username);
                if (isLeagalUsername) {


                    f.setTitle(username);
                    showtext.setText("Enter texts");
                    textField1.setText("");
                    showtext.setVisible(false);
                    button1.setVisible(false);
                    textField1.setVisible(false);
                    Thread t1 = new Thread(() -> whiteboardMenu());
                    Thread t2 = new Thread(() -> updateCanvas());

                    try {
                        // Getting the registry
                        Registry registry = LocateRegistry.getRegistry(null);
                        // Looking up the registry for the remote object
                        up = (UpdateList) registry.lookup("UpdateList");
                        System.out.println(up == null);
                        // Calling the remote method using the obtained object
                        graphicList = up.updateGraphics();

                    } catch (Exception exc) {
                        System.out.println("Client exception: " + exc);
                    }
                    ArrayList<Color> colorArray = new ArrayList<>(List.of(new Color(153, 153, 255), new Color(102, 204, 255), new Color(128, 64, 1), new Color(181, 230, 29), Color.BLUE, Color.CYAN, Color.GREEN, new Color(100, 100, 0), Color.RED, Color.BLACK, Color.ORANGE, Color.MAGENTA, Color.YELLOW, new Color(127, 127, 127)));


                    for (int i = 0; i < 30; i++) {
                        JButton button = new JButton();
                        button.setOpaque(true);
                        button.setBorderPainted(false);
                        if (i >= colorArray.size()) {
                            Random rand = new Random((long) Math.pow(i, 10));
                            button.setBackground(new Color(rand.nextFloat(), rand.nextFloat(), rand.nextFloat()));
                        } else {
                            button.setBackground(colorArray.get(i));
                        }
                        button.addActionListener(ee -> currentColour = button.getBackground());
                        button.setPreferredSize(new Dimension(30, 30));
                        Panel.add(button);

                    }

                    t1.start();
                    t2.start();
                }

            }
        });
    }

    // Interface updates every 80 milliseconds
    protected void updateCanvas() {
        while (true) {
            try {
                if (canvas != null) {
                    graphicList = up.updateGraphics();
                    canvas.repaint();
                }
                Map<String, Long> usernames = up.updateUser(username);
                if (!usernames.isEmpty()) {
                    String outUsers = "Welcome\n" + username + " !\n\nOther Users:\n";
                    for (String name : usernames.keySet()) {
                        if (!name.equals(username)){
                            outUsers = outUsers.concat(name + "\n");
                        }
                    }
                    userlist.setText(outUsers);
                } else {
                    f.dispose();
                    paint.dispose();
                }
                String newChat = up.getChat();
                chatArea.setText(newChat);
                Thread.sleep(80);
            } catch (InterruptedException | RemoteException ex) {
                System.err.println(ex.toString());
            } catch (ConcurrentModificationException e) {
                System.out.println();
            }

        }
    }

    protected void sendChat() {
        // send chat and set it back
        try {
            up.addChat(username + ": " + typeChat.getText());
            typeChat.setText("");
        } catch (RemoteException e) {
            System.err.println(e);
        }
    }

    protected void whiteboardMenu() {
        // set the frame
        paint.setTitle("White Board(" + username + ")");
        paint.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        paint.setLocationRelativeTo(null);
        paint.setLayout(new FlowLayout(FlowLayout.RIGHT));
        paint.setVisible(true);
        jp.setPreferredSize(new Dimension(100, 600));
        JPanel mid = new JPanel(new GridLayout(2, 1, 10, 10));
        mid.setPreferredSize(new Dimension(80, 599));


        JScrollPane scrollUserList = new JScrollPane(userlist);
        JScrollPane scrollChat = new JScrollPane(chatArea);
        chatArea.setEditable(false);
        userlist.setEditable(false);


        // Button to select shapes
        JButton buttonL = new JButton("Line");
        buttonL.addActionListener(e -> currentShape = "Line");
        jp.add(buttonL);
        JButton buttonO = new JButton("Oval");
        buttonO.addActionListener(e -> currentShape = "Oval");
        jp.add(buttonO);
        JButton buttonR = new JButton("Rectangle");
        buttonR.addActionListener(e -> currentShape = "Rectangle");
        jp.add(buttonR);
        JButton buttonT = new JButton("Triangle");
        buttonT.addActionListener(e -> currentShape = "Triangle");
        jp.add(buttonT);
        JButton buttonS = new JButton("Text");
        buttonS.addActionListener(e -> {
            currentShape = "Text";
            inputArea.setBackground(Color.WHITE);
        });
        jp.add(buttonS);

        inputArea.setEditable(true);
        inputArea.setLineWrap(true);
        inputArea.setWrapStyleWord(true);
        jp.add(inputArea);

        addFunctionalButtons();

        canvas = new JPanel() {
            public void paint(Graphics g) {
                grap = (Graphics2D) g;
                super.paint(g);
                // draw all the shapes in the list
                if (graphicList.size() > 0) {
                    for (TheGraphic tg : graphicList) {
                        g.setColor(new Color(tg.colour));
                        if (tg.shape.equalsIgnoreCase("Oval")) {
                            g.drawOval(Math.min(tg.location[0], tg.location[1]), Math.min(tg.location[2], tg.location[3]), Math.abs(tg.location[0] - tg.location[1]), Math.abs(tg.location[2] - tg.location[3]));
                        } else if (tg.shape.equalsIgnoreCase("Rectangle")) {
                            g.drawRect(Math.min(tg.location[0], tg.location[1]), Math.min(tg.location[2], tg.location[3]), Math.abs(tg.location[0] - tg.location[1]), Math.abs(tg.location[2] - tg.location[3]));
                        } else if (tg.shape.equalsIgnoreCase("Triangle")) {

                            g.drawPolygon(new int[]{tg.location[0], (tg.location[0] + tg.location[1]) / 2, tg.location[1]}, new int[]{tg.location[3], tg.location[2], tg.location[3]}, 3);
                        } else if (tg.shape.equalsIgnoreCase("Line")) {
                            g.drawLine(tg.location[0], tg.location[2], tg.location[1], tg.location[3]);
                        } else {
                            String[] texts = tg.shape.split(" ");
                            if (texts[0].equalsIgnoreCase("Text")) {
                                g.drawString(texts[1], tg.location[0], tg.location[2]);
                            }
                        }
                    }
                }

            }
        };
        grap = (Graphics2D) canvas.getGraphics();
        canvas.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // if mouse clicked, draw text
                y2 = e.getY();
                x2 = e.getX();
                if (currentShape.equalsIgnoreCase("Text")) {
                    try {
                        if (!inputArea.getText().equalsIgnoreCase("")) {
                            String dtext = currentShape + " " + inputArea.getText();
                            graphicList = up.updateGraphics(new TheGraphic(dtext, currentColour, new int[]{x1, x2, y1, y2}));
                        }
                    } catch (RemoteException ex) {
                        ex.printStackTrace();
                    }
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {
                x1 = e.getX();
                y1 = e.getY();
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                // Draw according to the position of the mouse movement
                y2 = e.getY();
                x2 = e.getX();

                try {
                    if (currentShape.equalsIgnoreCase("Text")) {
                        if (!inputArea.getText().equalsIgnoreCase("")) {

                            String dtext = currentShape + " " + inputArea.getText();
                            graphicList = up.updateGraphics(new TheGraphic(dtext, currentColour, new int[]{x1, x2, y1, y2}));
                        }
                    } else {
                        System.out.println(currentShape);
                        graphicList = up.updateGraphics(new TheGraphic(currentShape, currentColour, new int[]{x1, x2, y1, y2}));
                    }
                } catch (RemoteException ex) {
                    ex.printStackTrace();
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
        canvas.setPreferredSize(new Dimension(600, 600));
        canvas.setBackground(Color.WHITE);

        paint.add(canvas);
        mid.add(scrollUserList);
        mid.add(scrollChat);
        paint.add(mid);
        paint.add(jp);

        paint.pack();

    }


    public void addFunctionalButtons() {
        //  These buttons will not be used in Clinet

        JButton bUndo = new JButton();
        bUndo.addActionListener(e -> {
        });
        jp.add(bUndo);
        bUndo.setBackground(new Color(238, 238, 238));
        bUndo.setOpaque(true);
        bUndo.setBorderPainted(false);

        JButton bnew = new JButton("new");
        bnew.addActionListener(e -> {
        });
        jp.add(bnew);
        bnew.setText("");
        bnew.setBackground(new Color(238, 238, 238));
        bnew.setOpaque(true);
        bnew.setBorderPainted(false);

        JButton open = new JButton("open");
        open.addActionListener(e -> {
        });
        jp.add(open);
        open.setText("");
        open.setBackground(new Color(238, 238, 238));
        open.setOpaque(true);
        open.setBorderPainted(false);

        JButton save = new JButton("save");
        save.addActionListener(e -> {
        });
        jp.add(save);
        save.setText("");
        save.setBackground(new Color(238, 238, 238));
        save.setOpaque(true);
        save.setBorderPainted(false);

        JButton saveAs = new JButton("save as");
        saveAs.addActionListener(e -> {
        });
        jp.add(saveAs);
        saveAs.setText("");
        saveAs.setBackground(new Color(238, 238, 238));
        saveAs.setOpaque(true);
        saveAs.setBorderPainted(false);

        JButton close = new JButton("close");
        close.addActionListener(e -> {
        });
        jp.add(close);
        close.setText("");
        close.setBackground(new Color(238, 238, 238));
        close.setOpaque(true);
        close.setBorderPainted(false);

        JButton send = new JButton("send");
        send.addActionListener(e -> sendChat());

        JTextArea tarea = new JTextArea();
        tarea.setEditable(false);
        tarea.setBackground(jp.getBackground());
        jp.add(tarea);
        jp.add(typeChat);
        jp.add(send);

    }


    public static void main(String[] args) throws Exception {
        if (args.length == 2) {
            ip = args[0];
            port = Integer.parseInt(args[1]);
        }
        System.out.println("Server IP: " + ip + "\nHost: " + port);
        f = new JFrame("WhiteboardClient");
        f.setContentPane(new Client().Panel);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.pack();
        f.setVisible(true);

    }
}