// Runzhe Hua 1310690


import javax.net.ServerSocketFactory;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;


public class Server extends ImplUpdate {
    private static int port = 3614;

    private static long preTime = new Date().getTime();

    private static final Object lock = new Object();

    public Server() {
    }

    public static void main(String args[]) {
        if (args.length == 1) {
            port = Integer.parseInt(args[0]);
        }
        try {
            /* RMI */
            ImplUpdate obj = new ImplUpdate();
            UpdateList stub = (UpdateList) UnicastRemoteObject.exportObject(obj, 0);
            // Binding the remote object
            Registry registry = LocateRegistry.getRegistry();
            registry.bind("UpdateList", stub);
            System.out.println(" The remote object bound");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
        ServerSocketFactory factory = ServerSocketFactory.getDefault();

        try (ServerSocket server = factory.createServerSocket(port)) {
            System.out.println("\n Waiting for client connection on " + port);

            // Wait for connections.
            while (true) {
                Socket cSocket = server.accept();

                Thread t = new Thread(() -> serveClient(cSocket));
                t.start();

                if (new Date().getTime() - preTime > 1000) {
                    for (String name : usernames.keySet()) {
                        long preTime = new Date().getTime();
                        if (preTime - usernames.get(name) > 300) {
                            synchronized (lock) {
                                usernames.remove(name);
                            }
                        }
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void serveClient(Socket clientSocket) {
        synchronized (lock) {

            try {
                // Input stream
                DataInputStream input = new DataInputStream(clientSocket.getInputStream());
                // Output Stream
                DataOutputStream output = new DataOutputStream(clientSocket.getOutputStream());

                String clientUsername = input.readUTF();

                if (usernames.containsKey(clientUsername)) {
                    output.writeUTF("Name is used");
                } else {
                    usernames.put(clientUsername, new Date().getTime());
                    output.writeUTF("Name accepted");
                    System.out.println("new user: " + clientUsername);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }
} 