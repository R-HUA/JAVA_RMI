// Runzhe Hua 1310690


import com.google.gson.Gson;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.rmi.RemoteException;
import java.util.ArrayList;

public class Manager extends Client {
    File curretfile;

    public Manager() throws Exception {
        super();
    }

    @Override
    public void addFunctionalButtons() {
        // other functional buttons

        JButton bnew = new JButton("new");
        bnew.addActionListener(e -> {
            try {
                up.removeAllGraphics();
            } catch (RemoteException ex) {
                ex.printStackTrace();
            }
        });
        jp.add(bnew);


        JButton open = new JButton("open");
        open.addActionListener(e -> {
            try {
                //Select file
                JFileChooser chooser = new JFileChooser();
                chooser.showOpenDialog(null);
                File file = chooser.getSelectedFile();

                if (file != null) {
                    FileInputStream fis = new FileInputStream(file);
                    ArrayList<String> readJsonList = new ArrayList<>();
                    ArrayList<TheGraphic> newGraphic= new ArrayList<>();
                    readJsonList = new Gson().fromJson(readTo(file), readJsonList.getClass());
                    for (String js: readJsonList){
                        newGraphic.add(new Gson().fromJson(js, TheGraphic.class));

                    }
                    fis.close();
                    curretfile = file;
                    up.replaceGraphics(newGraphic);
                }

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        jp.add(open);


        JButton save = new JButton("save");
        save.addActionListener(e -> {
            if (curretfile != null) {
                savef(curretfile);
            } else {
                File file = new File("Paint " + username + ".json");
                savef(file);
            }
        });
        jp.add(save);


        JButton saveAs = new JButton("save as");
        saveAs.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            chooser.showSaveDialog(null);
            File file = chooser.getSelectedFile();

            if (file != null) {
                savef(file);
            }
        });
        jp.add(saveAs);


        JButton close = new JButton("close");
        close.addActionListener(e -> {
            try {
                up.removeAllGraphics();
                curretfile = null;
            } catch (RemoteException ex) {
                ex.printStackTrace();
            }
        });
        jp.add(close);

        typeChat.setText("");
        JButton sendButton = new JButton("send");
        sendButton.addActionListener(e -> sendChat());

        JTextField kickArea = new JTextField();
        JButton kickB = new JButton("kick out");
        kickB.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    up.kickUser(kickArea.getText());
                } catch (RemoteException ex) {
                    ex.printStackTrace();
                }
            }
        });
        jp.add(kickArea);
        jp.add(kickB);
        jp.add(typeChat);
        jp.add(sendButton);
        f.setTitle("Manager:" + username);
        paint.setTitle("White Board (Manager: " + username + ")");
    }

    public void savef(File file) {
        try {
            FileOutputStream fos = new FileOutputStream(file);
            ArrayList<String> jsonList = new ArrayList<>();
            for (TheGraphic tg : graphicList){
                jsonList.add(new Gson().toJson(tg));
            }
            byte[] data = new Gson().toJson(jsonList).getBytes();
            fos.write(data);
            fos.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private String readTo(File file) {
        // Get the contents of a file as a String
        String encoding = "UTF-8";
        Long filelength = file.length();
        byte[] filecontent = new byte[filelength.intValue()];
        try {
            FileInputStream in = new FileInputStream(file);
            in.read(filecontent);
            in.close();
        } catch (FileNotFoundException e) {
            System.out.println("Cannot find the file. \n");
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        try {
            return new String(filecontent, encoding);
        } catch (UnsupportedEncodingException e) {
            System.err.println("The OS does not support " + encoding);
            e.printStackTrace();
            return null;
        }
    }

    @Override
    protected void whiteboardMenu() {
        super.whiteboardMenu();
    }

    public static void main(String[] args) throws Exception {
        if (args.length == 2) {
            ip = args[0];
            port = Integer.parseInt(args[1]);
        }
        System.out.println("Server IP: " + ip + "\nHost: " + port);
        f = new JFrame("Manager");
        f.setContentPane(new Manager().Panel);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.pack();
        f.setVisible(true);

    }
}
