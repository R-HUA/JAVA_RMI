// Runzhe Hua 1310690


import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


// Creating Remote interface for our application 
public interface UpdateList extends Remote {
   ArrayList<TheGraphic> list = new ArrayList<>();
   Map<String, Long> usernames= new HashMap<>(){};
   ArrayList<String> chat = new ArrayList<>();



   ArrayList<TheGraphic> updateGraphics(TheGraphic t) throws RemoteException;
   ArrayList<TheGraphic> updateGraphics() throws RemoteException;
   Map<String, Long> updateUser(String username) throws RemoteException;
   void kickUser(String username) throws RemoteException;
   void addChat(String newChat) throws RemoteException;
   void removeAllGraphics() throws RemoteException;
   void replaceGraphics(ArrayList<TheGraphic> newList) throws RemoteException;
   String getChat() throws RemoteException;
} 
