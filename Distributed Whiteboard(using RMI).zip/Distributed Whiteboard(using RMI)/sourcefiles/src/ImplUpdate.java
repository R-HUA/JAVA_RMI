// Runzhe Hua 1310690


import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

// Implementing the remote interface
public class ImplUpdate implements UpdateList {

   public ArrayList<TheGraphic> updateGraphics(TheGraphic t) throws RemoteException {
      list.add(t);
      System.out.println("added "+ t.shape);
      return list;
   }

   @Override
   public ArrayList<TheGraphic> updateGraphics() throws RemoteException {
      return list;
   }

   @Override
   public Map<String, Long> updateUser(String username) throws RemoteException {
      if (usernames.containsKey(username)){
         usernames.put(username,new Date().getTime());
         for(String name: usernames.keySet()){
            long current_time = new Date().getTime();
            if (current_time - usernames.get(name) > 300){
               usernames.remove(name);
            }
         }
         return usernames;
      }
      else{
         return new HashMap<String, Long>();
      }

   }

   @Override
   public void kickUser(String username) throws RemoteException {
      usernames.remove(username);
   }

   @Override
   public void addChat(String newChat) throws RemoteException {
      chat.add(newChat + "\n");
      System.out.println("new chat: " + newChat);
   }

   @Override
   public void removeAllGraphics() throws RemoteException {
      list.clear();
   }

   public void replaceGraphics(ArrayList<TheGraphic> newList) throws RemoteException {
      list.clear();
      System.out.println("replace");
      list.addAll(newList);
   }


   @Override
   public String getChat() throws RemoteException {
      String allChats = "Chats:\n";
      for (String c: chat){
         allChats = allChats.concat(c);
      }
      return allChats;
   }
}
